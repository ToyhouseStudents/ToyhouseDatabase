#!/bin/sh
# This script fetches the MetaWiki database file from our downloads/ dir,
# original resides on http://sunir.org/meatball/MetaWiki/metadb

wget http://erfurtwiki.sourceforge.net/downloads/contrib-add-ons/metadb
