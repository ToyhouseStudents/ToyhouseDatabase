<?php

/*
   these definitions fake some of the markup found in �miki�
*/

$ewiki_config["wm_start_end"][] = array("[_", "_]", "<u>", "</u>");
$ewiki_config["wm_start_end"][] = array("[*", "*]", "<b>", "</b>");
$ewiki_config["wm_start_end"][] = array("[/", "/]", "<i>", "</i>");

?>